from fastapi import FastAPI
import pickle
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from imblearn.over_sampling import RandomOverSampler
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

app = FastAPI()

# Cargar el conjunto de datos de diabetes
df = pd.read_csv('diabetes.csv')

# Preprocesamiento de datos
X = df.drop('Outcome', axis=1)
y = df['Outcome']

# Escalado de características
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Dividir el conjunto de datos preprocesado en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.4, random_state=42)

@app.get("/")
def read_root():
    return {"API": "Modelo de predicción de diabetes"}

@app.get("/train")
def train_model():
    # Entrenar el modelo SVM
    svm = SVC()
    svm.fit(X_train, y_train)

    # Validación cruzada para evaluar el rendimiento del modelo SVM
    cv_scores = cross_val_score(svm, X_train, y_train, cv=5)

    # Ajustar los hiperparámetros del modelo SVM para optimizar su rendimiento
    parameters = {'C': [0.1, 1, 10], 'kernel': ['linear', 'rbf']}
    grid_search = GridSearchCV(svm, parameters)
    grid_search.fit(X_train, y_train)

    # Devolver los resultados del entrenamiento
    response = {
        "cross_validation_scores": cv_scores.tolist(),
        "best_parameters": grid_search.best_params_,
        "model_saved": True
    }

    return response

@app.get("/predict")
def predict(pregnancies: int, glucose: int, blood_pressure: int, skin_thickness: int, insulin: int,
            bmi: float, diabetes_pedigree_function: float, age: int):
    # Cargar el modelo SVM guardado desde el archivo .pkl
    with open('svm_model.pkl', 'rb') as file:
        svm_model = pickle.load(file)

    # Preprocesar los datos de entrada de muestra
    input_data = [[pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi,
                   diabetes_pedigree_function, age]]
    input_data_scaled = scaler.transform(input_data)

    # Realizar la predicción utilizando el modelo SVM
    prediction = svm_model.predict(input_data_scaled)

    # Definir las clases y sus descripciones
    classes = {
        0: {
            "name": "No diabetes",
            "description": "El paciente no tiene diabetes."
        },
        1: {
            "name": "Diabetes",
            "description": "El paciente tiene diabetes."
        }
    }

    # Obtener la descripción y otros detalles según la clase predicha
    predicted_class = int(prediction[0])
    class_name = classes[predicted_class]["name"]
    class_description = classes[predicted_class]["description"]

    # Crear un diccionario de respuesta que contiene la predicción
    response = {
        "prediction": predicted_class,
        "class_name": class_name,
        "class_description": class_description,
        "pregnancies": pregnancies,
        "glucose": glucose,
        "blood_pressure": blood_pressure,
        "skin_thickness": skin_thickness,
        "insulin": insulin,
        "bmi": bmi,
        "diabetes_pedigree_function": diabetes_pedigree_function,
        "age": age
    }

    return response
